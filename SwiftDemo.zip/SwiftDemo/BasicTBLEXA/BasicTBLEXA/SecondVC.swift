//
//  SecondVC.swift
//  BasicTBLEXA
//
//  Created by multicoreViral on 9/2/15.
//  Copyright (c) 2015 multicore. All rights reserved.
//

import UIKit

class SecondVC: UIViewController,IQAudioRecorderControllerDelegate {

    @IBOutlet var lblMain: UILabel!
    var strSel: String!
    
    var objIQ: IQAudioRecorderController = IQAudioRecorderController ()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        lblMain.text = strSel
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func btn_Clicked(sender: AnyObject) {
        objIQ.delegate = self
        
        self.presentViewController(objIQ, animated: true, completion: nil)
    }
    func audioRecorderController(controller: IQAudioRecorderController!, didFinishWithAudioAtPath filePath: String!) {
        println(filePath)
    }

    func audioRecorderControllerDidCancel(controller: IQAudioRecorderController!) {
        
    }
}
