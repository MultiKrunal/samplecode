//
//  ViewControllerCell.swift
//  BasicTBLEXA
//
//  Created by multicoreViral on 9/2/15.
//  Copyright (c) 2015 multicore. All rights reserved.
//

import UIKit

class ViewControllerCell: UITableViewCell {
    
    var strSelected:String!
    
    @IBOutlet var lblText: UILabel!
    
    func setData(){
        lblText.text = strSelected
    }
}
