//
//  ViewController.swift
//  Exa1
//
//  Created by multicoreViral on 7/22/15.
//  Copyright (c) 2015 multicore. All rights reserved.
//

import UIKit

class ViewController: UIViewController,IQAudioRecorderControllerDelegate {

    @IBOutlet weak var tblData:UITableView?
    var objIQRecorder = IQAudioRecorderController ()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.navigationItem.title = "Hello world"
        
//        var frame = CGRectMake(10, 68, 300, 200)
//        objIQRecorder.view.frameForAlignmentRect(frame)
        objIQRecorder.willMoveToParentViewController(self)
        self.view.addSubview(objIQRecorder.view)
//        self.view.sendSubviewToBack(<#view: UIView#>)
        self.addChildViewController(objIQRecorder)
        objIQRecorder.didMoveToParentViewController(self);
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func audioRecorderController(controller: IQAudioRecorderController!, didFinishWithAudioAtPath filePath: String!) {
        println(filePath)
    }
    func audioRecorderControllerDidCancel(controller: IQAudioRecorderController!) {
        
    }

}

