//
//  ViewController.swift
//  ObjectDeclaration
//
//  Created by multicoreViral on 8/14/15.
//  Copyright (c) 2015 multicore. All rights reserved.
//

import UIKit
let number = 5

class ViewController: UIViewController {
    
    var str1 = "HELLO WORLD"
    var str2 : String!
    let str3 = "Multicore"
    
    var arr = NSMutableArray ()
    var dic1 = ["key1": "val1","key2":"val2"]
    var dic2 = NSMutableDictionary ()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        str2 = "ANY THING"
        arr.addObject("\(str2)")
        
//        println("My FIRST PROJECT \(str1) \(str2)")
        
        println("dic1 \(dic1) arr \(arr)")
        // Do any additional setup after loading the view, typically from a nib.
        
/*        for var i=0; i<arr.count; i++ {
            
        }
//        var i: Int
        for (var i) in 10...15{
            println("i \(i)")
        }
*/
        let someCharacter: Character = "b"
        
/*        switch someCharacter {
        case "a", "e", "i", "o", "u":
            print("\(someCharacter) is a vowel")
        case "b", "c", "d", "f", "g", "h", "j", "k", "l", "m",
        "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z":
            print("\(someCharacter) is a consonant")
        default:
            print("\(someCharacter) is not a vowel or a consonant")
        }

        var i = 2
        switch i{
        case 1,3:
            println(i)
        case 4:
            println(i)
        case 5:
            println(i)
        default:
            println("default")
        }
*/
        var str4 = HelloWorld(5,xyz: 5)
        println(str4)
        
    }
    

   
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func HelloWorld(abc:Int, xyz:Int)->Int{
        return abc + xyz
    }

}

